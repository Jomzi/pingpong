﻿namespace UWP_Accelerometer
{
    internal class await
    {
    }
}